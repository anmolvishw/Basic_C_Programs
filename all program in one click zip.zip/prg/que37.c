#include<stdio.h>
int main()
{
    int a=20;
    // Left and Right Shift
    printf("Values are : %d",a);
    printf("\nOutput of Left Shift  : %d",a<<1);
    printf("\nOutput of Right Shift : %d",a>>1);
}

