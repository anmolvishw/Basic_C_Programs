#include<stdio.h>
int main()
{
    int a=20,b=21;
    // Bitwise Operation
    printf("Values are : %d %d",a,b);
    printf("\nOutput of Bitwise & (AND)     : %d",a&b);
    printf("\nOutput of Bitwise & (OR)      : %d",a|b);
    printf("\nOutput of Bitwise & (XOR)     : %d",a^b);
    printf("\nOutput of Bitwise ~b (Nagation): %d",~a);
    printf("\nOutput of Bitwise ~a (Nagation): %d",~b);
}
