#include<stdio.h>
int main()
{
    int arr[5]={6,7,8,0,4};   // 1-D array & asign
    // printing array values in Console

    printf(" values are : ");
        for(int i=0;i<5; i++)
            printf("%d ",arr[i]);

        return 0;

}
